#include "calculate.h"
#include "add.h"
#include "sub.h"

int add(int a, int b) {
    return a + b;
}

int sub(int a, int b) {
    return a - b;
}

int calculate(int a, int b, char op) {
    switch (op) {
        case '+': return add(a, b);
        case '-': return sub(a, b);
        default: return 0;
    }
}

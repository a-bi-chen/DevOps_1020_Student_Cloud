#include <stdio.h>
#include "extra.h"
#include "config.h"
#include "calculate.h"

int main(void) {
    int result = calculate(3, 2, '-');
    printf("%d\n", VALUE + result - 1 + EXTRA);
    return 0;
}

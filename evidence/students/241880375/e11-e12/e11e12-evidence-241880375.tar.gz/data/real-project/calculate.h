int calculate(int, int, char);

#include <stdio.h>
#include "config.h"
#include "calculate.h"

int main(void) {
    int result = calculate(3, 2, '-');
    printf("%d\n", VALUE + result - 1);
    return 0;
}
